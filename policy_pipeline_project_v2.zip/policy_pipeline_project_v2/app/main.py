from __future__ import annotations
import argparse
from app.config import load_config
from app.schema_manager import ensure_schema
from app.session_manager import create_session
from app.services.pipeline_service import PipelineService


def main() -> None:
    parser = argparse.ArgumentParser(description="Policy-level Snowflake extraction pipeline")
    parser.add_argument("command", choices=["setup", "run"], help="setup=create tables, run=run pipeline")
    args = parser.parse_args()

    config = load_config()
    session = create_session(config)

    try:
        if args.command == "setup":
            ensure_schema(session, config)
            print("Schema created successfully.")
            return

        ensure_schema(session, config)
        PipelineService(session, config).run()
        print("Pipeline completed successfully.")
    finally:
        session.close()


if __name__ == "__main__":
    main()
