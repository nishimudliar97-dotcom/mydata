from __future__ import annotations
import json
import re
from typing import Any, Iterable, List
from snowflake.snowpark import Session
from snowflake.snowpark.functions import ai_extract, to_file
from app.config import AppConfig
from app.models import FileExtractionResult, ParsedSection, PolicyExtracted, SourceFile


class ExtractorService:
    def __init__(self, session: Session, config: AppConfig) -> None:
        self.session = session
        self.config = config

    def extract_file(self, file: SourceFile, parsed_sections: Iterable[ParsedSection]) -> FileExtractionResult:
        file_uri = f"@{self.config.stage}/{file.stage_relative_path}"
        df = self.session.range(1).select(
            ai_extract(
                to_file(file_uri),
                self.config.extraction_questions,
            ).alias('EXTRACTED_JSON')
        )
        raw_value = df.collect()[0][0]
        extracted = self._safe_load_json(raw_value)

        result = FileExtractionResult(
            file_id=file.file_id,
            policy_number=file.policy_number,
            document_name=file.document_name,
            source_type=file.source_type,
            policy_number_value=self._to_str(extracted.get('policy_number')),
            claim_number=self._to_str(extracted.get('claim_number')),
            loss_date=self._to_str(extracted.get('loss_date')),
            sum_insured=self._to_float(extracted.get('sum_insured')),
            decline_reason=self._to_str(extracted.get('decline_reason')),
        )

        sections = list(parsed_sections)
        if result.claim_number:
            sec = self._find_source_section(result.claim_number, sections)
            if sec:
                result.claim_number_section, result.claim_number_page = sec.section_name, sec.page_number
        if result.loss_date:
            sec = self._find_source_section(result.loss_date, sections)
            if sec:
                result.loss_date_section, result.loss_date_page = sec.section_name, sec.page_number
        if result.sum_insured is not None:
            sec = self._find_source_section(str(int(result.sum_insured)) if float(result.sum_insured).is_integer() else str(result.sum_insured), sections)
            if sec:
                result.sum_insured_section, result.sum_insured_page = sec.section_name, sec.page_number
        if result.decline_reason:
            sec = self._find_source_section(result.decline_reason, sections)
            if sec:
                result.decline_reason_section, result.decline_reason_page = sec.section_name, sec.page_number

        return result

    def consolidate_policy(self, policy_number: str, file_results: List[FileExtractionResult]) -> PolicyExtracted:
        output = PolicyExtracted(policy_number=policy_number)
        for result in file_results:
            bucket = self._bucket_name(result.document_name, result.source_type)
            if bucket is None:
                continue
            self._set_with_metadata(output, f'claim_number_{bucket}', result.claim_number, result.document_name, result.claim_number_section, result.claim_number_page)
            self._set_with_metadata(output, f'loss_date_{bucket}', result.loss_date, result.document_name, result.loss_date_section, result.loss_date_page)
            self._set_with_metadata(output, f'sum_insured_{bucket}', result.sum_insured, result.document_name, result.sum_insured_section, result.sum_insured_page)
            self._set_with_metadata(output, f'decline_reason_{bucket}', result.decline_reason, result.document_name, result.decline_reason_section, result.decline_reason_page)
        return output

    def save_policy_extracted(self, policy: PolicyExtracted) -> None:
        delete_sql = f"""
            DELETE FROM {self.config.policy_extracted_table}
            WHERE POLICY_NUMBER = '{policy.policy_number.replace("'", "''")}'
        """
        self.session.sql(delete_sql).collect()

        row = [[
            policy.policy_number,

            policy.claim_number_email, policy.claim_number_email_document, policy.claim_number_email_section, policy.claim_number_email_page,
            policy.claim_number_doc1, policy.claim_number_doc1_document, policy.claim_number_doc1_section, policy.claim_number_doc1_page,
            policy.claim_number_doc2, policy.claim_number_doc2_document, policy.claim_number_doc2_section, policy.claim_number_doc2_page,
            policy.claim_number_doc3, policy.claim_number_doc3_document, policy.claim_number_doc3_section, policy.claim_number_doc3_page,

            policy.loss_date_email, policy.loss_date_email_document, policy.loss_date_email_section, policy.loss_date_email_page,
            policy.loss_date_doc1, policy.loss_date_doc1_document, policy.loss_date_doc1_section, policy.loss_date_doc1_page,
            policy.loss_date_doc2, policy.loss_date_doc2_document, policy.loss_date_doc2_section, policy.loss_date_doc2_page,
            policy.loss_date_doc3, policy.loss_date_doc3_document, policy.loss_date_doc3_section, policy.loss_date_doc3_page,

            policy.sum_insured_email, policy.sum_insured_email_document, policy.sum_insured_email_section, policy.sum_insured_email_page,
            policy.sum_insured_doc1, policy.sum_insured_doc1_document, policy.sum_insured_doc1_section, policy.sum_insured_doc1_page,
            policy.sum_insured_doc2, policy.sum_insured_doc2_document, policy.sum_insured_doc2_section, policy.sum_insured_doc2_page,
            policy.sum_insured_doc3, policy.sum_insured_doc3_document, policy.sum_insured_doc3_section, policy.sum_insured_doc3_page,

            policy.decline_reason_email, policy.decline_reason_email_document, policy.decline_reason_email_section, policy.decline_reason_email_page,
            policy.decline_reason_doc1, policy.decline_reason_doc1_document, policy.decline_reason_doc1_section, policy.decline_reason_doc1_page,
            policy.decline_reason_doc2, policy.decline_reason_doc2_document, policy.decline_reason_doc2_section, policy.decline_reason_doc2_page,
            policy.decline_reason_doc3, policy.decline_reason_doc3_document, policy.decline_reason_doc3_section, policy.decline_reason_doc3_page,
        ]]
        schema = [
            'POLICY_NUMBER',
            'CLAIM_NUMBER_EMAIL', 'CLAIM_NUMBER_EMAIL_DOCUMENT', 'CLAIM_NUMBER_EMAIL_SECTION', 'CLAIM_NUMBER_EMAIL_PAGE',
            'CLAIM_NUMBER_DOC1', 'CLAIM_NUMBER_DOC1_DOCUMENT', 'CLAIM_NUMBER_DOC1_SECTION', 'CLAIM_NUMBER_DOC1_PAGE',
            'CLAIM_NUMBER_DOC2', 'CLAIM_NUMBER_DOC2_DOCUMENT', 'CLAIM_NUMBER_DOC2_SECTION', 'CLAIM_NUMBER_DOC2_PAGE',
            'CLAIM_NUMBER_DOC3', 'CLAIM_NUMBER_DOC3_DOCUMENT', 'CLAIM_NUMBER_DOC3_SECTION', 'CLAIM_NUMBER_DOC3_PAGE',
            'LOSS_DATE_EMAIL', 'LOSS_DATE_EMAIL_DOCUMENT', 'LOSS_DATE_EMAIL_SECTION', 'LOSS_DATE_EMAIL_PAGE',
            'LOSS_DATE_DOC1', 'LOSS_DATE_DOC1_DOCUMENT', 'LOSS_DATE_DOC1_SECTION', 'LOSS_DATE_DOC1_PAGE',
            'LOSS_DATE_DOC2', 'LOSS_DATE_DOC2_DOCUMENT', 'LOSS_DATE_DOC2_SECTION', 'LOSS_DATE_DOC2_PAGE',
            'LOSS_DATE_DOC3', 'LOSS_DATE_DOC3_DOCUMENT', 'LOSS_DATE_DOC3_SECTION', 'LOSS_DATE_DOC3_PAGE',
            'SUM_INSURED_EMAIL', 'SUM_INSURED_EMAIL_DOCUMENT', 'SUM_INSURED_EMAIL_SECTION', 'SUM_INSURED_EMAIL_PAGE',
            'SUM_INSURED_DOC1', 'SUM_INSURED_DOC1_DOCUMENT', 'SUM_INSURED_DOC1_SECTION', 'SUM_INSURED_DOC1_PAGE',
            'SUM_INSURED_DOC2', 'SUM_INSURED_DOC2_DOCUMENT', 'SUM_INSURED_DOC2_SECTION', 'SUM_INSURED_DOC2_PAGE',
            'SUM_INSURED_DOC3', 'SUM_INSURED_DOC3_DOCUMENT', 'SUM_INSURED_DOC3_SECTION', 'SUM_INSURED_DOC3_PAGE',
            'DECLINE_REASON_EMAIL', 'DECLINE_REASON_EMAIL_DOCUMENT', 'DECLINE_REASON_EMAIL_SECTION', 'DECLINE_REASON_EMAIL_PAGE',
            'DECLINE_REASON_DOC1', 'DECLINE_REASON_DOC1_DOCUMENT', 'DECLINE_REASON_DOC1_SECTION', 'DECLINE_REASON_DOC1_PAGE',
            'DECLINE_REASON_DOC2', 'DECLINE_REASON_DOC2_DOCUMENT', 'DECLINE_REASON_DOC2_SECTION', 'DECLINE_REASON_DOC2_PAGE',
            'DECLINE_REASON_DOC3', 'DECLINE_REASON_DOC3_DOCUMENT', 'DECLINE_REASON_DOC3_SECTION', 'DECLINE_REASON_DOC3_PAGE',
        ]
        df = self.session.create_dataframe(row, schema=schema)
        df.write.mode('append').save_as_table(self.config.policy_extracted_table)

    def _bucket_name(self, document_name: str, source_type: str) -> str | None:
        name = document_name.lower()
        if source_type.upper() == 'EMAIL' or 'email' in name:
            return 'email'
        if 'doc1' in name or 'document1' in name:
            return 'doc1'
        if 'doc2' in name or 'document2' in name:
            return 'doc2'
        if 'doc3' in name or 'document3' in name:
            return 'doc3'
        return None

    def _set_with_metadata(self, policy: PolicyExtracted, prefix: str, value: Any, document_name: str, section: str | None, page: int | None) -> None:
        setattr(policy, prefix, value)
        setattr(policy, f'{prefix}_document', document_name)
        setattr(policy, f'{prefix}_section', section)
        setattr(policy, f'{prefix}_page', page)

    def _safe_load_json(self, raw_value: Any) -> Any:
        if raw_value is None:
            return {}
        if isinstance(raw_value, dict):
            return raw_value
        try:
            return json.loads(str(raw_value))
        except Exception:
            return {}

    def _to_str(self, value: Any) -> str | None:
        if value is None:
            return None
        text = str(value).strip()
        return text or None

    def _to_float(self, value: Any) -> float | None:
        if value is None:
            return None
        text = re.sub(r'[^0-9.]', '', str(value))
        if not text:
            return None
        try:
            return float(text)
        except ValueError:
            return None

    def _normalize_text(self, text: str) -> str:
        return re.sub(r'\s+', ' ', text.strip().lower())

    def _find_source_section(self, value: str, sections: List[ParsedSection]) -> ParsedSection | None:
        target = self._normalize_text(value)
        if not target:
            return None
        for section in sections:
            if target in self._normalize_text(section.ocr_text):
                return section
        best = None
        best_score = 0
        target_tokens = set(target.split())
        for section in sections:
            candidate_tokens = set(self._normalize_text(section.ocr_text).split())
            score = len(target_tokens.intersection(candidate_tokens))
            if score > best_score:
                best_score = score
                best = section
        return best if best_score > 0 else None
