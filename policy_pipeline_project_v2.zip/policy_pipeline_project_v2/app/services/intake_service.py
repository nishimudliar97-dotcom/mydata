from __future__ import annotations
from typing import Iterable
from snowflake.snowpark import Session
from app.config import AppConfig
from app.models import SourceFile


class IntakeService:
    def __init__(self, session: Session, config: AppConfig) -> None:
        self.session = session
        self.config = config

    def upsert_files(self, files: Iterable[SourceFile]) -> dict[str, str]:
        result: dict[str, str] = {}
        for item in files:
            existing = self._get_existing_file(item.file_id)
            if existing is None:
                self._insert_new(item)
                result[item.file_id] = 'NEW'
                continue

            existing_hash = (existing.get('FILE_HASH') or '').strip() or None
            existing_modified = (existing.get('LAST_MODIFIED') or '').strip() or None
            existing_path = (existing.get('STAGE_RELATIVE_PATH') or '').strip()

            changed = False
            if item.file_hash and existing_hash and item.file_hash != existing_hash:
                changed = True
            elif item.last_modified and existing_modified and item.last_modified != existing_modified:
                changed = True
            elif item.stage_relative_path != existing_path:
                changed = True

            if changed:
                self._update_existing(item, status='UPDATED')
                result[item.file_id] = 'UPDATED'
            else:
                result[item.file_id] = 'UNCHANGED'
        return result

    def policy_exists_in_final_output(self, policy_number: str) -> bool:
        sql = f"""
            SELECT 1
            FROM {self.config.policy_extracted_table}
            WHERE POLICY_NUMBER = '{policy_number.replace("'", "''")}'
            LIMIT 1
        """
        return len(self.session.sql(sql).collect()) > 0

    def has_new_or_updated_files(self, policy_number: str) -> bool:
        sql = f"""
            SELECT 1
            FROM {self.config.policy_file_intake_table}
            WHERE POLICY_NUMBER = '{policy_number.replace("'", "''")}'
              AND STATUS IN ('NEW', 'UPDATED', 'FAILED')
            LIMIT 1
        """
        return len(self.session.sql(sql).collect()) > 0

    def get_files_to_process(self, files: Iterable[SourceFile], change_map: dict[str, str]) -> list[SourceFile]:
        return [f for f in files if change_map.get(f.file_id) in {'NEW', 'UPDATED'}]

    def mark_file_status(self, file_id: str, status: str, error_message: str | None = None) -> None:
        err_sql = 'NULL' if not error_message else f"'{error_message.replace("'", "''")[:5000]}'"
        processed_sql = 'CURRENT_TIMESTAMP()' if status in {'PARSED', 'EXTRACTED', 'SKIPPED'} else 'PROCESSED_AT'
        sql = f"""
            UPDATE {self.config.policy_file_intake_table}
            SET STATUS = '{status.replace("'", "''")}',
                PROCESSED_AT = {processed_sql},
                ERROR_MESSAGE = {err_sql}
            WHERE FILE_ID = '{file_id.replace("'", "''")}'
        """
        self.session.sql(sql).collect()

    def mark_policy_files_processed(self, policy_number: str) -> None:
        sql = f"""
            UPDATE {self.config.policy_file_intake_table}
            SET STATUS = 'EXTRACTED',
                PROCESSED_AT = CURRENT_TIMESTAMP(),
                ERROR_MESSAGE = NULL
            WHERE POLICY_NUMBER = '{policy_number.replace("'", "''")}'
              AND STATUS IN ('NEW', 'UPDATED', 'PARSED', 'FAILED')
        """
        self.session.sql(sql).collect()

    def _get_existing_file(self, file_id: str) -> dict | None:
        sql = f"""
            SELECT FILE_ID, FILE_HASH, LAST_MODIFIED, STAGE_RELATIVE_PATH
            FROM {self.config.policy_file_intake_table}
            WHERE FILE_ID = '{file_id.replace("'", "''")}'
            LIMIT 1
        """
        rows = self.session.sql(sql).collect()
        return rows[0].as_dict() if rows else None

    def _insert_new(self, item: SourceFile) -> None:
        rows = [[
            item.file_id,
            item.policy_number,
            item.document_name,
            item.source_type,
            item.source_table,
            item.file_name,
            self.config.stage,
            item.stage_relative_path,
            'NEW',
            None,
            None,
            item.file_hash,
            item.last_modified,
        ]]
        df = self.session.create_dataframe(rows, schema=[
            'FILE_ID', 'POLICY_NUMBER', 'DOCUMENT_NAME', 'DOCUMENT_TYPE', 'SOURCE_TABLE', 'FILE_NAME',
            'STAGE_NAME', 'STAGE_RELATIVE_PATH', 'STATUS', 'PROCESSED_AT', 'ERROR_MESSAGE', 'FILE_HASH', 'LAST_MODIFIED'
        ])
        df.write.mode('append').save_as_table(self.config.policy_file_intake_table)

    def _update_existing(self, item: SourceFile, status: str) -> None:
        sql = f"""
            UPDATE {self.config.policy_file_intake_table}
            SET DOCUMENT_NAME = '{item.document_name.replace("'", "''")}',
                DOCUMENT_TYPE = '{item.source_type.replace("'", "''")}',
                SOURCE_TABLE = '{item.source_table.replace("'", "''")}',
                FILE_NAME = '{item.file_name.replace("'", "''")}',
                STAGE_NAME = '{self.config.stage.replace("'", "''")}',
                STAGE_RELATIVE_PATH = '{item.stage_relative_path.replace("'", "''")}',
                FILE_HASH = {('NULL' if not item.file_hash else "'" + item.file_hash.replace("'", "''") + "'")},
                LAST_MODIFIED = {('NULL' if not item.last_modified else "'" + item.last_modified.replace("'", "''") + "'")},
                STATUS = '{status}',
                ERROR_MESSAGE = NULL
            WHERE FILE_ID = '{item.file_id.replace("'", "''")}'
        """
        self.session.sql(sql).collect()
