from __future__ import annotations
import json
from typing import Any, List
from snowflake.snowpark import Session
from snowflake.snowpark.functions import ai_parse_document, to_file
from app.config import AppConfig
from app.models import ParsedSection, SourceFile


class ParserService:
    def __init__(self, session: Session, config: AppConfig) -> None:
        self.session = session
        self.config = config

    def parse_file(self, file: SourceFile) -> List[ParsedSection]:
        file_uri = f"@{self.config.stage}/{file.stage_relative_path}"
        df = self.session.range(1).select(
            ai_parse_document(
                to_file(file_uri),
                mode=self.config.parse_mode,
                page_split=self.config.page_split,
                return_error_details=True,
            ).alias('PARSED_JSON')
        )
        raw_value = df.collect()[0][0]
        parsed_obj = self._safe_load_json(raw_value)
        if isinstance(parsed_obj, dict) and parsed_obj.get('error'):
            raise RuntimeError(f"AI_PARSE_DOCUMENT failed for {file.document_name}: {parsed_obj['error']}")

        value_obj = parsed_obj.get('value', parsed_obj) if isinstance(parsed_obj, dict) else parsed_obj
        sections = self._to_sections(file, value_obj)
        self._delete_existing_sections(file.file_id)
        self._save_sections(sections)
        return sections

    def _delete_existing_sections(self, file_id: str) -> None:
        sql = f"DELETE FROM {self.config.document_parsed_table} WHERE FILE_ID = '{file_id.replace("'", "''")}'"
        self.session.sql(sql).collect()

    def _safe_load_json(self, raw_value: Any) -> Any:
        if raw_value is None:
            return {}
        if isinstance(raw_value, (dict, list)):
            return raw_value
        try:
            return json.loads(str(raw_value))
        except Exception:
            return {'raw_text': str(raw_value)}

    def _to_sections(self, file: SourceFile, parsed_obj: Any) -> List[ParsedSection]:
        sections: List[ParsedSection] = []
        if isinstance(parsed_obj, dict) and isinstance(parsed_obj.get('pages'), list):
            for index, page in enumerate(parsed_obj['pages'], start=1):
                ocr_text = self._extract_text(page)
                section_name = self._infer_section_name(ocr_text, index)
                sections.append(
                    ParsedSection(
                        file_id=file.file_id,
                        policy_number=file.policy_number,
                        document_name=file.document_name,
                        source_type=file.source_type,
                        section_id=f"{file.file_id}_SEC_{index}",
                        section_name=section_name,
                        page_number=index,
                        parsed_output=page,
                        ocr_text=ocr_text,
                        parse_status='SUCCESS',
                    )
                )
        else:
            ocr_text = self._extract_text(parsed_obj)
            sections.append(
                ParsedSection(
                    file_id=file.file_id,
                    policy_number=file.policy_number,
                    document_name=file.document_name,
                    source_type=file.source_type,
                    section_id=f"{file.file_id}_SEC_1",
                    section_name=self._infer_section_name(ocr_text, 1),
                    page_number=1,
                    parsed_output=parsed_obj,
                    ocr_text=ocr_text,
                    parse_status='SUCCESS',
                )
            )
        return sections

    def _extract_text(self, node: Any) -> str:
        if isinstance(node, dict):
            for key in ['text', 'content', 'markdown', 'raw_text']:
                val = node.get(key)
                if isinstance(val, str) and val.strip():
                    return val
            return json.dumps(node, ensure_ascii=False)
        if isinstance(node, list):
            return '\n'.join(self._extract_text(item) for item in node)
        return str(node or '')

    def _infer_section_name(self, text: str, page_no: int) -> str:
        for line in text.splitlines():
            clean = line.strip()
            if clean:
                return clean[:500]
        return f'Page {page_no}'

    def _save_sections(self, sections: List[ParsedSection]) -> None:
        if not sections:
            return
        rows = []
        for s in sections:
            rows.append([
                s.file_id, s.policy_number, s.document_name, s.section_id,
                s.section_name, s.page_number, s.parsed_output, s.ocr_text, s.parse_status,
            ])
        df = self.session.create_dataframe(
            rows,
            schema=['FILE_ID', 'POLICY_NUMBER', 'DOCUMENT_NAME', 'SECTION_ID', 'SECTION_NAME', 'PAGE_NUMBER', 'PARSED_OUTPUT', 'OCR_TEXT', 'PARSE_STATUS'],
        )
        df.write.mode('append').save_as_table(self.config.document_parsed_table)
