from __future__ import annotations
from snowflake.snowpark import Session
from app.config import AppConfig


class LoggingService:
    def __init__(self, session: Session, config: AppConfig) -> None:
        self.session = session
        self.config = config

    def log(self, policy_number: str, file_id: str | None, document_name: str | None, step_name: str, step_status: str, message: str) -> None:
        rows = [[policy_number, file_id, document_name, step_name, step_status, message]]
        df = self.session.create_dataframe(
            rows,
            schema=['POLICY_NUMBER', 'FILE_ID', 'DOCUMENT_NAME', 'STEP_NAME', 'STEP_STATUS', 'MESSAGE'],
        )
        df.write.mode('append').save_as_table(self.config.document_process_log_table)
