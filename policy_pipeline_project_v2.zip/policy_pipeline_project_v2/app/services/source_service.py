from __future__ import annotations
from typing import Dict, List
from snowflake.snowpark import Session
from app.config import AppConfig
from app.models import SourceFile


class SourceService:
    def __init__(self, session: Session, config: AppConfig) -> None:
        self.session = session
        self.config = config

    def load_source_files(self) -> List[SourceFile]:
        queries = [
            (
                f'''
                SELECT POLICY_NUMBER, DOCUMENT_NAME, FILE_NAME, STAGE_RELATIVE_PATH,
                       TRY_TO_VARCHAR(FILE_HASH) AS FILE_HASH,
                       TRY_TO_VARCHAR(LAST_MODIFIED) AS LAST_MODIFIED
                FROM {self.config.email_source_table}
                WHERE POLICY_NUMBER IS NOT NULL AND STAGE_RELATIVE_PATH IS NOT NULL
                ''',
                'EMAIL',
                self.config.email_source_table,
            ),
            (
                f'''
                SELECT POLICY_NUMBER, DOCUMENT_NAME, FILE_NAME, STAGE_RELATIVE_PATH,
                       TRY_TO_VARCHAR(FILE_HASH) AS FILE_HASH,
                       TRY_TO_VARCHAR(LAST_MODIFIED) AS LAST_MODIFIED
                FROM {self.config.document_source_table}
                WHERE POLICY_NUMBER IS NOT NULL AND STAGE_RELATIVE_PATH IS NOT NULL
                ''',
                'DOCUMENT',
                self.config.document_source_table,
            ),
        ]
        output: List[SourceFile] = []
        for query, source_type, source_table in queries:
            for row in self.session.sql(query).collect():
                output.append(
                    SourceFile(
                        policy_number=str(row['POLICY_NUMBER']).strip(),
                        document_name=str(row['DOCUMENT_NAME']).strip(),
                        source_type=source_type,
                        source_table=source_table,
                        file_name=str(row['FILE_NAME']).strip(),
                        stage_relative_path=str(row['STAGE_RELATIVE_PATH']).strip(),
                        file_hash=(str(row['FILE_HASH']).strip() if row['FILE_HASH'] else None),
                        last_modified=(str(row['LAST_MODIFIED']).strip() if row['LAST_MODIFIED'] else None),
                    )
                )
        return output

    def group_by_policy(self, files: List[SourceFile]) -> Dict[str, List[SourceFile]]:
        grouped: Dict[str, List[SourceFile]] = {}
        for item in files:
            grouped.setdefault(item.policy_number, []).append(item)
        return grouped
