from __future__ import annotations
from snowflake.snowpark import Session
from app.config import AppConfig
from app.services.extractor_service import ExtractorService
from app.services.intake_service import IntakeService
from app.services.logging_service import LoggingService
from app.services.parser_service import ParserService
from app.services.source_service import SourceService


class PipelineService:
    def __init__(self, session: Session, config: AppConfig) -> None:
        self.session = session
        self.config = config
        self.source_service = SourceService(session, config)
        self.intake_service = IntakeService(session, config)
        self.parser = ParserService(session, config)
        self.extractor = ExtractorService(session, config)
        self.logger = LoggingService(session, config)

    def run(self) -> None:
        source_files = self.source_service.load_source_files()
        grouped = self.source_service.group_by_policy(source_files)

        for policy_number, files in grouped.items():
            change_map = self.intake_service.upsert_files(files)
            files_to_process = self.intake_service.get_files_to_process(files, change_map)
            policy_exists = self.intake_service.policy_exists_in_final_output(policy_number)

            if policy_exists and not files_to_process and not self.intake_service.has_new_or_updated_files(policy_number):
                self.logger.log(policy_number, None, None, 'POLICY_CHECK', 'SUCCESS', 'No new or updated files found. Skipping policy.')
                continue

            if not files_to_process:
                self.logger.log(policy_number, None, None, 'POLICY_CHECK', 'SUCCESS', 'Policy exists, but nothing new to process. Skipping policy.')
                continue

            try:
                file_results = []
                for file in files_to_process:
                    self.logger.log(policy_number, file.file_id, file.document_name, 'REGISTER', 'SUCCESS', f'File status = {change_map.get(file.file_id)}')
                    self.logger.log(policy_number, file.file_id, file.document_name, 'PARSE_START', 'SUCCESS', 'Starting parse.')
                    parsed_sections = self.parser.parse_file(file)
                    self.intake_service.mark_file_status(file.file_id, 'PARSED')
                    self.logger.log(policy_number, file.file_id, file.document_name, 'PARSE_END', 'SUCCESS', f'Parsed {len(parsed_sections)} sections.')
                    self.logger.log(policy_number, file.file_id, file.document_name, 'EXTRACT_START', 'SUCCESS', 'Starting extraction.')
                    result = self.extractor.extract_file(file, parsed_sections)
                    self.intake_service.mark_file_status(file.file_id, 'EXTRACTED')
                    file_results.append(result)
                    self.logger.log(policy_number, file.file_id, file.document_name, 'EXTRACT_END', 'SUCCESS', 'Extraction completed.')

                final_policy = self.extractor.consolidate_policy(policy_number, file_results)
                self.extractor.save_policy_extracted(final_policy)
                self.intake_service.mark_policy_files_processed(policy_number)
                self.logger.log(policy_number, None, None, 'POLICY_SAVE', 'SUCCESS', 'Saved final policy-level extracted row.')
            except Exception as exc:
                safe_message = str(exc)[:5000]
                for file in files_to_process:
                    self.intake_service.mark_file_status(file.file_id, 'FAILED', safe_message)
                self.logger.log(policy_number, None, None, 'PIPELINE', 'FAILED', safe_message)
