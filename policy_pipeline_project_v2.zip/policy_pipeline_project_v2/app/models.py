from __future__ import annotations
from dataclasses import dataclass
from typing import Any


@dataclass
class SourceFile:
    policy_number: str
    document_name: str
    source_type: str
    source_table: str
    file_name: str
    stage_relative_path: str
    file_hash: str | None = None
    last_modified: str | None = None

    @property
    def file_id(self) -> str:
        import re
        seed = f"{self.policy_number}_{self.document_name}_{self.file_name}_{self.stage_relative_path}"
        clean = re.sub(r"[^A-Za-z0-9]+", "_", seed).strip("_").upper()
        return f"FILE_{clean[:180]}"


@dataclass
class ParsedSection:
    file_id: str
    policy_number: str
    document_name: str
    source_type: str
    section_id: str
    section_name: str
    page_number: int | None
    parsed_output: Any
    ocr_text: str
    parse_status: str


@dataclass
class FileExtractionResult:
    file_id: str
    policy_number: str
    document_name: str
    source_type: str
    policy_number_value: str | None = None
    claim_number: str | None = None
    claim_number_section: str | None = None
    claim_number_page: int | None = None
    loss_date: str | None = None
    loss_date_section: str | None = None
    loss_date_page: int | None = None
    sum_insured: float | None = None
    sum_insured_section: str | None = None
    sum_insured_page: int | None = None
    decline_reason: str | None = None
    decline_reason_section: str | None = None
    decline_reason_page: int | None = None


@dataclass
class PolicyExtracted:
    policy_number: str

    claim_number_email: str | None = None
    claim_number_email_document: str | None = None
    claim_number_email_section: str | None = None
    claim_number_email_page: int | None = None
    claim_number_doc1: str | None = None
    claim_number_doc1_document: str | None = None
    claim_number_doc1_section: str | None = None
    claim_number_doc1_page: int | None = None
    claim_number_doc2: str | None = None
    claim_number_doc2_document: str | None = None
    claim_number_doc2_section: str | None = None
    claim_number_doc2_page: int | None = None
    claim_number_doc3: str | None = None
    claim_number_doc3_document: str | None = None
    claim_number_doc3_section: str | None = None
    claim_number_doc3_page: int | None = None

    loss_date_email: str | None = None
    loss_date_email_document: str | None = None
    loss_date_email_section: str | None = None
    loss_date_email_page: int | None = None
    loss_date_doc1: str | None = None
    loss_date_doc1_document: str | None = None
    loss_date_doc1_section: str | None = None
    loss_date_doc1_page: int | None = None
    loss_date_doc2: str | None = None
    loss_date_doc2_document: str | None = None
    loss_date_doc2_section: str | None = None
    loss_date_doc2_page: int | None = None
    loss_date_doc3: str | None = None
    loss_date_doc3_document: str | None = None
    loss_date_doc3_section: str | None = None
    loss_date_doc3_page: int | None = None

    sum_insured_email: float | None = None
    sum_insured_email_document: str | None = None
    sum_insured_email_section: str | None = None
    sum_insured_email_page: int | None = None
    sum_insured_doc1: float | None = None
    sum_insured_doc1_document: str | None = None
    sum_insured_doc1_section: str | None = None
    sum_insured_doc1_page: int | None = None
    sum_insured_doc2: float | None = None
    sum_insured_doc2_document: str | None = None
    sum_insured_doc2_section: str | None = None
    sum_insured_doc2_page: int | None = None
    sum_insured_doc3: float | None = None
    sum_insured_doc3_document: str | None = None
    sum_insured_doc3_section: str | None = None
    sum_insured_doc3_page: int | None = None

    decline_reason_email: str | None = None
    decline_reason_email_document: str | None = None
    decline_reason_email_section: str | None = None
    decline_reason_email_page: int | None = None
    decline_reason_doc1: str | None = None
    decline_reason_doc1_document: str | None = None
    decline_reason_doc1_section: str | None = None
    decline_reason_doc1_page: int | None = None
    decline_reason_doc2: str | None = None
    decline_reason_doc2_document: str | None = None
    decline_reason_doc2_section: str | None = None
    decline_reason_doc2_page: int | None = None
    decline_reason_doc3: str | None = None
    decline_reason_doc3_document: str | None = None
    decline_reason_doc3_section: str | None = None
    decline_reason_doc3_page: int | None = None
