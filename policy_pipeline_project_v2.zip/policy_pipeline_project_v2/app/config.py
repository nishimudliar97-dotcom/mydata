from __future__ import annotations

import os
from dataclasses import dataclass
from dotenv import load_dotenv


@dataclass(frozen=True)
class AppConfig:
    account: str
    user: str
    password: str
    warehouse: str
    database: str
    schema: str
    role: str | None
    stage: str
    email_source_table: str
    document_source_table: str
    policy_file_intake_table: str
    document_parsed_table: str
    policy_extracted_table: str
    document_process_log_table: str
    parse_mode: str
    page_split: bool
    source_system_name: str

    @property
    def extraction_questions(self) -> dict[str, str]:
        return {
            "policy_number": "What is the policy number in this file? Return only the policy number if found.",
            "claim_number": "What is the claim number in this file? Return only the claim number if found.",
            "loss_date": "What is the loss date in this file? Return only the date if found.",
            "sum_insured": "What is the sum insured in this file? Return only the amount if found.",
            "decline_reason": "What is the decline reason in this file? Return only the decline reason text if found.",
        }


def _get_bool(name: str, default: bool) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "y"}


def load_config() -> AppConfig:
    load_dotenv()
    return AppConfig(
        account=os.environ["SNOWFLAKE_ACCOUNT"],
        user=os.environ["SNOWFLAKE_USER"],
        password=os.environ["SNOWFLAKE_PASSWORD"],
        warehouse=os.environ["SNOWFLAKE_WAREHOUSE"],
        database=os.environ["SNOWFLAKE_DATABASE"],
        schema=os.environ["SNOWFLAKE_SCHEMA"],
        role=os.getenv("SNOWFLAKE_ROLE"),
        stage=os.environ["SNOWFLAKE_STAGE"],
        email_source_table=os.environ["EMAIL_SOURCE_TABLE"],
        document_source_table=os.environ["DOCUMENT_SOURCE_TABLE"],
        policy_file_intake_table=os.environ["POLICY_FILE_INTAKE_TABLE"],
        document_parsed_table=os.environ["DOCUMENT_PARSED_TABLE"],
        policy_extracted_table=os.environ["POLICY_EXTRACTED_TABLE"],
        document_process_log_table=os.environ["DOCUMENT_PROCESS_LOG_TABLE"],
        parse_mode=os.getenv("PARSE_MODE", "LAYOUT").upper(),
        page_split=_get_bool("PAGE_SPLIT", True),
        source_system_name=os.getenv("SOURCE_SYSTEM_NAME", "SNOWFLAKE_INTERNAL"),
    )
