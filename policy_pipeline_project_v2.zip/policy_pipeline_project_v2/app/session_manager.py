from __future__ import annotations
from snowflake.snowpark import Session
from app.config import AppConfig


def create_session(config: AppConfig) -> Session:
    params = {
        "account": config.account,
        "user": config.user,
        "password": config.password,
        "warehouse": config.warehouse,
        "database": config.database,
        "schema": config.schema,
    }
    if config.role:
        params["role"] = config.role
    return Session.builder.configs(params).create()
