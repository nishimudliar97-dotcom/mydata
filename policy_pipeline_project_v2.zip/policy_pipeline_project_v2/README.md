# Policy Pipeline Project v2

This version adds **new / updated file detection**.

## Detection logic
- New policy: policy not present in `POLICY_EXTRACTED`
- New document: `FILE_ID` not present in `POLICY_FILE_INTAKE`
- Updated document: same `FILE_ID`, but `FILE_HASH`, `LAST_MODIFIED`, or `STAGE_RELATIVE_PATH` changed
- Unchanged document: same `FILE_ID` and same metadata, so skip

## Expected source table columns
Both source tables should expose:
- `POLICY_NUMBER`
- `DOCUMENT_NAME`
- `FILE_NAME`
- `STAGE_RELATIVE_PATH`
- `FILE_HASH` (optional but recommended)
- `LAST_MODIFIED` (optional but recommended)

## Run
```bash
python -m app.main setup
python -m app.main run
```
