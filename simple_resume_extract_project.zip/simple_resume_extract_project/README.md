# Simple Resume Extraction Test Project

This is a minimal Snowpark Python project to test Snowflake `AI_EXTRACT`
on a single file already present in a Snowflake stage.

It extracts:
- full name
- email address
- phone number

## Run
1. Create and activate a virtual environment
2. `pip install -r requirements.txt`
3. Copy `.env.example` to `.env`
4. Fill Snowflake credentials, stage name, and file name
5. Run:

```bash
python -m app.main
```
