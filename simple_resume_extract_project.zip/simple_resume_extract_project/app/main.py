import json
from snowflake.snowpark.functions import ai_extract, to_file
from .config import load_config
from .session_manager import create_session

QUESTIONS = [
    "What is the full candidate name in this resume? Return only the full name.",
    "What is the primary email address in this resume? Return only the email address.",
    "What is the phone number shown near the candidate name? Return only the phone number.",
]

def main() -> None:
    config = load_config()
    session = create_session(config)
    try:
        file_uri = f"@{config.stage_name}/{config.file_name}"
        print(f"Running extraction for: {file_uri}")

        df = session.range(1).select(
            ai_extract(
                to_file(file_uri),
                QUESTIONS,
            ).alias("EXTRACTED_OUTPUT")
        )

        result = df.collect()[0]["EXTRACTED_OUTPUT"]

        if isinstance(result, str):
            try:
                result = json.loads(result)
            except json.JSONDecodeError:
                pass

        print("\n=== RAW OUTPUT ===")
        print(json.dumps(result, indent=2, ensure_ascii=False))

        response = result.get("response", {}) if isinstance(result, dict) else {}
        print("\n=== CLEAN OUTPUT ===")
        print("Name :", response.get(QUESTIONS[0]))
        print("Email:", response.get(QUESTIONS[1]))
        print("Phone:", response.get(QUESTIONS[2]))
    finally:
        session.close()

if __name__ == "__main__":
    main()
